var process = function() {
	   "use strict";
        return {


 createStones : function(time) {
    setInterval(function() {
        stones= stone.create(-100,320, "stone");
        stones.body.velocity.x=300;
          stones= stone.create(-300,120, "stone");
        stones.body.velocity.x=300;
    },time);
}, 


createMagmas : function(time){
    setInterval(function(){
        magmas = magma.create(-100,320, "stone");
        magmas.body.velocity.x=300;
           magmas = magma.create(-300,120, "stone");
        magmas.body.velocity.x=300;
            magmas = magma.create(-500,220, "stone");
        magmas.body.velocity.x=300;
    },time);
},

createPers : function(time){
    setInterval(function(){
        pers = per.create(-100,320, "stone");
        pers.body.velocity.x=300;
          perss = per.create(-300,120, "stone");
        pers.body.velocity.x=300;
            pers = per.create(-500,220, "stone");
        pers.body.velocity.x=300;
    },time);
},


killMe: function(player, stone){
    player.kill();
    soundeffects.play();
  
    game.state.start("Gameover");

},
killMagma: function(player, magma){
        soundeffects.play();
    player.kill();
  
    game.state.start("Gameover2");

},
killPer: function(player, per){
        soundeffects.play();
    player.kill();
  
    game.state.start("Gameover3");

},
 

 
audio : function(time){
    setInterval(function(){
        bgAudio.play();
        },time)
 

},






start1: function(player, level){
    game.state.start("level2");
},

start2: function(player, level){
    game.state.start("level3");
},
start3: function(player, level){
    game.state.start("Congrats");
},
    restart:function(){
        game.state.start("Game");
    },
    pause : function(){
    game.paused = true;
    pauseText.text = 'Tap to Unpause';
},

    unpause:  function (event){

   game.paused = false;
    pauseText.text = '';
},
    
 left : function(){
       player.body.velocity.x = -150;

        player.animations.play('left');
            score += 0;
         scoreText.text = 'Score: ' + score;
    },

     right : function(){
       player.body.velocity.x = +150;

        player.animations.play('right');
            score += 0;
         scoreText.text = 'Score: ' + score;
    },
        go : function(){
          player.animations.play('jump-up');
            player.body.velocity.y=-2000;
           score += 1;
         scoreText.text = 'Score: ' + score;

    },
}
}();