var poste;
var text;
var ground, stone2, stones2;
var magma, magmas;
var btn;
var sky;
var level2 = {
 preload: function() {
 
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'red'; 
            game.load.image('poste', 'assets/wall.jpg');
            game.load.image('level', 'assets/level1.png');
            game.load.image('level2', 'assets/level2.png');
            game.load.image('level3', 'assets/level3.png');
            game.load.image('sky', 'assets/background1.jpg');
            game.load.image("star", 'assets/star.png',process.start);
            game.load.image("tao", 'assets/redball1.png');
            game.load.image('ground', 'assets/piko1.png');
            game.load.image("left", 'assets/left.png');
            game.load.image('right', 'assets/right.png');
            game.load.image('go', 'assets/go.png');
            game.load.image('next', 'assets/up.png',process.start2);
            game.load.image('stone', 'assets/stone.png');
            game.load.image('pause', 'assets/pause.png');
            game.load.image('restart', 'assets/restart.png');
            
      
          
           game.load.audio("soundeffects","music/kill.wav");

},
 create: function() {

   
            game.physics.startSystem(Phaser.Physics.ARCADE);
      
      
                 
                   game.add.sprite(200, 10, 'ground');
            platforms = game.add.group();
            platforms.enableBody = true;

            wall = game.add.group();
            wall.enableBody=true;
            var poste = wall.create(150,0,"poste");
            poste.body.immovable=true;
             var poste = wall.create(500,0,"poste");
            poste.body.immovable=true;
      

            soundeffects = game.add.audio("soundeffects");  
            btn = game.add.button(40,450,"left", process.left);
            btn.fixedToCamera=true;

            btn = game.add.button(550,450,'right', process.right);
            btn.fixedToCamera=true;


            btn = game.add.button(300,514,'go', process.go);
            btn.fixedToCamera=true;
      
             platforms = game.add.group();


             platforms.enableBody = true;
                  level = game.add.group();
            level.enableBody = true;
            var me = level.create(650,10,"level2");
             level=game.add.group();
             level.enableBody=true;
                  btn = game.add.button(530,10,"restart",process.restart);
            btn.fixedToCamera=true;
            
            game.input.onDown.add(process.unpause, self);
            btn = game.add.button(10,50,"pause",process.pause);
            btn.fixedToCamera=true;
          

            process.createMagmas(3000);
            magma=game.add.group();
            magma.enableBody=true;

           var ledge = level.create(300, -50, 'next',process.start2);
            ledge.body.immovable = true;
      

         

            player = game.add.sprite(300,500, 'tao');
           
            
            game.physics.arcade.enable(player);
               
            player.body.collideWorldBounds = true;

       
            


               player.animations.add('jump',[0,1,2],2,true);
  

     
    

            scoreText = game.add.text(16, 16, 'Score: 0', { fontSize: '32px', fill: 'white' });
           
           pauseText = game.add.text(280, 300, '', { fontSize: '120px', fill: 'red' });
           pauseText.fixedToCamera=true;
            messageText = game.add.text(280, 300, '', { fontSize: '120px', fill: 'red' });
             game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
          
             scoreText.fixedToCamera = true;
              messageText.fixedToCamera = true;
                game.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON);


   
            cursors = game.input.keyboard.createCursorKeys();
           
        keyboard = game.input.keyboard.createCursorKeys();
            
        },

update: function() {

    game.physics.arcade.collide(player, wall);
     game.physics.arcade.overlap(player, magma, process.killMagma);
 

    game.physics.arcade.overlap(player, level, process.start2);







      


player.body.velocity.x = 0;
    if(keyboard.right.isDown){
        player.body.velocity.x=210;
        player.animations.stop();
        game.camera.y +=1;
}
    else if(keyboard.left.isDown){;
        player.body.velocity.x=-210;
        game.camera.y +=1;
}

    else if(keyboard.up.isDown){
        player.body.velocity.y=-300;
        game.camera.y +=1;
}
    else if(keyboard.down.isDown){
        player.body.velocity.y=210;
        game.camera.y +=1;
}
    else{
        player.animations.play('jump');
        player.body.velocity.x=0;
        player.body.velocity.y=0;
        game.camera.y +=1;
    }
}
}
game.state.add("level2" ,level2, false);