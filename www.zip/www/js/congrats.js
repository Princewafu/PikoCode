var Congrats = {

    preload : function() {
         game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
        game.load.image('1', 'assets/coungrats.png');
         
    },

    create: function () {
        
        this.add.sprite(0, 0, '1');
             this.add.button(0, 0, '1', this.startGame, this);
    },

    startGame: function () {

        this.state.start('Menu');

    }


};
game.state.add("Congrats",Congrats,false);